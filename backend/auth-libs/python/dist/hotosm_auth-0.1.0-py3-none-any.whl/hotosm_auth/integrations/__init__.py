"""
Framework integrations for FastAPI and Django.
"""
